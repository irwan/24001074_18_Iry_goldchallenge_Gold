import re
import pandas as pd

from flask import Flask, jsonify

from flask import request
from flasgger import Swagger, LazyString, LazyJSONEncoder
from flasgger import swag_from
import plotly.express as px
from PIL import Image
from wordcloud import WordCloud, STOPWORDS, ImageColorGenerator
import matplotlib.pyplot as plt
import regex as re

#prerocessing
from collections import OrderedDict

from Sastrawi.Stemmer.StemmerFactory import StemmerFactory
from datetime import datetime

import nltk
nltk.download('stopwords')
from nltk.corpus import stopwords
from Sastrawi.StopWordRemover.StopWordRemoverFactory import StopWordRemoverFactory

#encoder
from sklearn.preprocessing import LabelEncoder

#split data
from sklearn.model_selection import train_test_split

#feture engineering
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.feature_extraction.text import TfidfTransformer
import numpy as np
from sklearn.feature_extraction.text import CountVectorizer

#modeling
from sklearn.svm import SVC

#evaluation model
from sklearn.metrics import confusion_matrix
from sklearn.metrics import accuracy_score
from datetime import datetime
import sqlite3
import seaborn as sns
import os
cwd = os.getcwd()
files = os.listdir(cwd)
print("Files in %r: %s" %(cwd, files))

app = Flask(__name__)

#membaca file csv abusive dan kamus alay
# %cd '/Users/irtea/bootcamp DSC/binar-data-science/gold_challenge'

df_abusive = pd.read_csv('/Users/irtea/bootcamp DSC/binar-data-science/gold_challenge/abusive.csv')
df_alay = pd.read_csv('/Users/irtea/bootcamp DSC/binar-data-science/gold_challenge/new_kamusalay.csv',encoding= 'latin-1')
df_alay.columns = ['kata_alay', 'kata_baku']

#mengeksport data abusive dan kamus alay ke database

connection=sqlite3.connect('db_gold_challenge.db')
cursorObj = connection.cursor()
df_abusive.to_sql(name='tb_abusive', con=connection, index=False, if_exists='replace')
df_alay.to_sql(name='tb_alay', con=connection, index=False, if_exists='replace')

data_abusive = pd.read_sql_query ('''select * from tb_abusive''',connection)
data_alay = pd.read_sql_query ('''select * from tb_alay''',connection)

#menyimpan data hasil cleansing ke Database

cursorObj.execute('''
    CREATE TABLE IF NOT EXISTS data_input (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        original_text TEXT,
        clean_text TEXT
    )
''')
connection.commit()

# function cleansing
def cleansing(sent):
    string = sent.lower() # mengkonversi ke huruf non kapital
    string = re.sub(r'<.*?>','', string)  #format html
    string = re.sub(r'&\S+','', string)  #format html
    string = re.sub(r'http\S+', '', string)  #Menghapus URL yang dimulai dengan "http".
    string = re.sub(r'www\.\S+','', string)  #format URL
    string = re.sub(r"\\x[a-fA-F0-9]{2}",'', string)  #format \xf0\x9f\x98\x82\xf0\x9f\x98\x82\xf0\x9f\x98\x82...
    string = string.replace('\\n', '')#enghapus string '/n'
    string = re.sub(r'\b(\w+)\b\s+\b\1\b', r'\1', string) #Menghapus kata-kata yang duplikat.
    string = re.sub(r'(\w)(\1{2,})', r"\1", string) #Menghapus karakter berulang lebih dari 2 kali.
    string = re.sub("(username|user|url|rt|xd)\s|\s(user|url|rt|xd)","",string)
    string = re.sub(r'[^a-zA-Z0-9]',' ', string) #Mengganti karakter non-alphanumeric dengan spasi.
    string = re.sub(r"\b[a-zA-Z]\b","",string) #menghapus kata-kata yang hanya terdiri dari satu huruf.
    string = re.sub('(s{2,})',' ',string) #Mengganti dua atau lebih spasi berturut-turut dengan satu spasi. 
    string = string.strip() #Menghapus spasi di awal dan akhir string.
  
    
    return string
    

# Function replace alay
database_alay = dict(zip(data_alay['kata_alay'], data_alay['kata_baku']))

def replace_alay(text, database_alay, compiled_alay_patterns):
    for alay_pattern, baku_word in zip(compiled_alay_patterns, database_alay.values()):
        text = alay_pattern.sub(baku_word, text)
    return text

compiled_alay_patterns = [re.compile(rf'\b{re.escape(alay_word)}\b', flags=re.IGNORECASE) for alay_word in database_alay.keys()]

# Function Sensor Abusive

database_kata_kasar = set(data_abusive['ABUSIVE'])

def sensor_kalimat(teks, database_kata_kasar):
    kata_kata = teks.split()
    kata_kata_bersih = [kata if kata.lower() not in database_kata_kasar else '*' * len(kata) for kata in kata_kata]
    kalimat_bersih = ' '.join(kata_kata_bersih)
    return kalimat_bersih


app.json_encoder = LazyJSONEncoder
swagger_template = {
    "info": {
        "title":  "API Documentation for Data Processing and Modeling",
        "version": "1.0.0",
        "description": "Dokumentasi API untuk Data Processing dan Modeling Tugas Gold Challenge an Irwan"
    },
    "host": "127.0.0.1:5000"
}

swagger_config = {
    "headers": [],
    "specs": [
        {
            "endpoint": 'docs',
            "route": '/docs.json',
        }
    ],
    "static_url_path": "/flasgger_static",
    "swagger_ui": True,
    "specs_route": "/docs/"
}
swagger = Swagger(app, template=swagger_template,             
                  config=swagger_config)

@swag_from("/Users/irtea/bootcamp DSC/binar-data-science/gold_challenge/docs/hello_world.yml", methods=['GET'])
@app.route('/', methods=['GET'])
def hello_world():
    json_response = {
        'status_code': 200,
        'description': "Menyapa Hello World",
        'data': "Hello World",
    }

    response_data = jsonify(json_response)
    return response_data

@swag_from("/Users/irtea/bootcamp DSC/binar-data-science/gold_challenge/docs/text.yml", methods=['GET'])
@app.route('/text', methods=['GET'])
def text():
    json_response = {
        'status_code': 200,
        'description': "Original Teks",
        'data': "Halo, apa kabar semua?",
    }

    response_data = jsonify(json_response)
    return response_data

@swag_from("/Users/irtea/bootcamp DSC/binar-data-science/gold_challenge/docs/text_clean.yml", methods=['GET'])
@app.route('/text-clean', methods=['GET'])
def text_clean():
    json_response = {
        'status_code': 200,
        'description': "Teks yang sudah dibersihkan",
        'data': re.sub(r'[^a-zA-Z0-9]', ' ', "Halo, apa kabar semua?"),
    }

    response_data = jsonify(json_response)
    return response_data

@swag_from("/Users/irtea/bootcamp DSC/binar-data-science/gold_challenge/docs/text_processing.yml", methods=['POST'])
@app.route('/text-processing', methods=['POST'])
def text_processing():

    text = request.form.get('text')

    # Menjalankan proses cleansing
    text_cleansing = cleansing(text)

    # Menjalankan proses mengganti kata alay
    text_cleansing_alay = replace_alay(text_cleansing, database_alay, compiled_alay_patterns)
    
    # Menjalankan proses sensor kata abusive
    text_cleansing_alay_sensor = sensor_kalimat(text_cleansing_alay, database_kata_kasar)

    # menyimpan hasil cleansing ke database 
    entities = (text, text_cleansing_alay_sensor)
    connection=sqlite3.connect('db_gold_challenge.db')
    cursorObj = connection.cursor()
    cursorObj.execute('''
        INSERT INTO data_input (original_text, clean_text)
        VALUES (?, ?)
    ''', entities)
    connection.commit()

    json_response = {
        'status_code': 200,
        'description': "Teks yang sudah diproses cleansing dan sensor abusive",
        'data': text_cleansing_alay_sensor,
    }

    response_data = jsonify(json_response)
    return response_data

@swag_from("/Users/irtea/bootcamp DSC/binar-data-science/gold_challenge/docs/text_processing_file.yml", methods=['POST'])
@app.route('/text-processing-file', methods=['POST'])
def text_processing_file():

    # Upladed file
    file = request.files.getlist('file')[0]

    # Import file csv ke Pandas
    df = pd.read_csv(file, encoding='latin1')
    
    #verifikasi data tweet apakah available 
    
    if 'Tweet' not in df.columns:
        raise ValueError('Column "Tweet" not found')
        
    # menghapus data yang duplicate
    df = df.drop_duplicates()

    # Ambil teks yang akan diproses dalam format list
    texts = df['Tweet'].to_list()

    # Lakukan cleansing pada teks
    df['Tweet_clean'] = df['Tweet'].apply(lambda x: cleansing(x))

    # Menjalankan proses mengganti kata alay dari kamus alay
    df['Tweet replace alay'] = df['Tweet_clean'].apply(lambda tweet: replace_alay(tweet, database_alay, compiled_alay_patterns))

    # Menjalankan proses mengganti kata alay dari kamus sastrawi
    # factory = StopWordRemoverFactory()
    # stopword = factory.create_stop_word_remover()
    # df['Tweet replace alay w/sastrawi'] = df['Tweet replace alay'].apply(lambda x: " ".join(stopword.remove(x) for x in x.split() ))
   
    # # Menjalankan proses mengganti kata alay dari NLTK
    # list_stopwords = set(stopwords.words('indonesian'))
    # df['Tweet replace alay /nltk'] = df['Tweet replace alay'].apply(lambda x: " ".join(x for x in x.split() if x not in list_stopwords))


    # Menjalankan proses sensor kata abusive
    df['Tweet Cleansing ALL'] = df['Tweet replace alay'].apply(lambda tweet: sensor_kalimat(tweet, database_kata_kasar))


    # menyimpan data ke database
    connection=sqlite3.connect('db_gold_challenge.db')
    cursorObj = connection.cursor()
    kolom_yang_diekspor = ['Tweet', 'Tweet Cleansing ALL']
    df_subset = df[kolom_yang_diekspor]
    df_subset.to_sql(name='tb_data_file_ir', con=connection, index=False, if_exists='replace')

    # mengubah data ke json
    cursor = connection.execute("SELECT * FROM tb_data_file_ir")
    data = cursor.fetchall()

    json_data = []
    for row in data:
        json_data.append( row[1]) #urutan kolom data tweet yang telah dicleansing
        
    
    json_response = {
        'status_code': 200,
        'description': "File yang sudah diproses cleansing dan sensor abusive",
        'data': json_data,
    }

    response_data = jsonify(json_response)
    
    #connection.close()
    return response_data


if __name__ == '__main__':
   app.run()

